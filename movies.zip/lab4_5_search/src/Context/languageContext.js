import React from "react"


//keda ka2ny create key bta3 language  ly haethat fl state
//createContext() mawgoda gwa React mesh mhtaga a install haga
export const LanguageContext = React.createContext()