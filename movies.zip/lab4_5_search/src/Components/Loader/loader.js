import React from "react";

export default function Loader() {
  return (
    <>
    <div class="spinner-border" role="status" style={{backgroundColor:"#34495e"}}>
    </div>
    <p>Loading...</p>
    </>

  );
}