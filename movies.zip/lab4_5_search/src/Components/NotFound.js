import React from 'react'

export default function NotFound() {
    return (
        <div style={{height:"100vh"}}>
           <h1 className='p-5'>404 not found </h1>
        </div>
    )
}
