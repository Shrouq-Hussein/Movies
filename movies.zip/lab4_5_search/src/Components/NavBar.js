import { Link } from "react-router-dom"
import { useSelector, useDispatch } from "react-redux"
import { changeLanguageAction } from "../Store/Actions/changeLanguageAction"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import "./NavBar.css";
import { LanguageContext } from './../Context/languageContext'
import { useContext } from "react";
import { useState } from "react";

export default function NavBar() {
    const [movieTitle, setmovieTitle] = useState(
        {
            title:""
        }
    )
   const  ChangeTitle = (e) => {
       console.log(e)
    setmovieTitle(
        {
            ...movieTitle,
            title : e.target.value,
        }
    )
   }

    //change language btare2et lcontext
    //useContext(name of context) da hook
    const { contextLanguage, setContextLanguage } = useContext(LanguageContext)
    //useSelector is a hook to get state values
    // const language = useSelector((state) => state.language.lang);
    const counter = useSelector((state) => state.counter.counter);

    //useDispatch is a hook to change state values | dispatch(action)
    const dispatch = useDispatch();
    const changeLanguage = () => {
        //awel tare2a redux
        // dispatch(changeLanguageAction(language === 'AR' ? 'EN' : 'AR'))
        //tany tare2a context
        setContextLanguage(contextLanguage === 'AR' ? 'EN' : 'AR')

    }
    console.log(movieTitle.title , "titllllllllllleeeeee")
    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container-fluid">
                <Link className="navbar-brand" to="/Movies">Movies</Link>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <Link className="nav-link" to="/Favorites">Favourit</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" aria-current="page" to="/SignUp">SignUp</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/Login">Login</Link>
                        </li>

                        <li className="nav-item row rightNav">
                            <span className="nav-link col-4 langNav " onClick={() => changeLanguage()}>{contextLanguage}</span>
                            <span className="col-4 nav-link"> {counter} </span>
                            <span className="col-4  nav-link">
                                <FontAwesomeIcon icon={faStar} className="fav" />
                            </span>

                        </li>
                    </ul>
                    <form className="d-flex">
                        <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" onChange={(e) => ChangeTitle(e)} />
                        <Link className="btn btn-outline-success" type="submit" key={"movie.id"}  to={`/SearchResults/${movieTitle.title}`}>Search</Link>
                    </form>
                </div>
            </div>
        </nav>
    )
}