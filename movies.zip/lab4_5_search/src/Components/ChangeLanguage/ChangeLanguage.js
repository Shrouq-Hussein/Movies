import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { changeLanguageAction } from '../../Store/Actions/changeLanguageAction';

export default function ChangeLanguage() {
    const language = useSelector((state) => state.language.lang);
    const dispatch =useDispatch();
    const changeLanguage = () =>{
       dispatch(changeLanguageAction(language ==="AR"?"ENG":"AR" ))

    }
  return <div> 
     <button className='btn btn-outline-primary' onClick={() => changeLanguage()}>Change language</button> 
      </div>;
}
