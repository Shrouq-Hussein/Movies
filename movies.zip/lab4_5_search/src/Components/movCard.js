// import React from 'react';
// import { Link } from 'react-router-dom'
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faStar } from "@fortawesome/free-solid-svg-icons";
// import { setfavmovies } from "./../Store/Actions/FavMovies";
// import { useSelector, useDispatch } from "react-redux"

// export default function movCard(props) {
//     const favourits =  useSelector((state) => state.FavMovies.favMovies);
//     console.log(favourits)
//     const dispatch = useDispatch();
//     const addMovieToFav = (props) => {
//         dispatch(ADD_FavMovies(props))
//         console.log(props,"detailsssss")
//     }

//   return(
//     <div className="card col-lg-3 col-md-5 col-sm-6 offset-1 p-3 mb-5 " style={{ backgroundColor: "#ecf0f1" }} key={props.index}  >
//     <Link key={props.id} to={`/Details/${props.id}`} >
//         <img src={`https://image.tmdb.org/t/p/w500/${props.poster}`} className="card-img-top" alt="..." />
//     </Link>

//     <div className="card-body">
//         <div className='row'>
//             <h5 className="card-title text-start col-6">{props.title}</h5>
//             <span className="text-end  col-6">
//                 <FontAwesomeIcon icon={faStar} className="me-2 my-2" style={{ color: "orange" }} onClick={() => addMovieToFav(props.movi)} />
//             </span>
//         </div>
//         <span >Vote Average:</span>
//         <span style={{ color: "red" }}> {props.vote_average}</span>
//         <span className='ms-3'>Vote Count:</span>
//         <span style={{ color: "red" }}> {props.vote_count}</span>
//     </div>
// </div>
//   );
// }
// //