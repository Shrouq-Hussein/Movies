import { useState } from "react";
import CustomInput from "../Components/Input";

export default function AddUser() {
  const [userForm, setUserForm] = useState({
    username: "",
    position: "",
  });

  const [errors, setErrors] = useState({
    usernameErr: null,
    positionErr: null,
  });

  const changeData = (e) => {
    if (e.target.name === "username") {
      setUserForm({
        ...userForm,
        username: e.target.value,
      });
      setErrors({
        ...errors,
        usernameErr:
          e.target.value.length === 0
            ? "This field is required"
            : e.target.value.length < 3
            ? "Min. length is 3 characters"
            : null,
      });
    } else if (e.target.name === "position") {
      setUserForm({
        ...userForm,
        position: e.target.value,
      });
    }
  };

  const submitUserDataForm = (e) => {
    e.preventDefault();
    if (!errors.usernameErr && !errors.positionErr) {
      // SEND API REQUEST
      console.log(userForm);
    }
  };

  return (
    <div className="container py-5">
      <h1>Add User Form</h1>
      <form onSubmit={(e) => submitUserDataForm(e)}>
        <CustomInput
          id={"usernameID"}
          label={"Username"}
          errors={errors.usernameErr}
          value={userForm.username}
          handleChange={(e) => changeData(e)}
          name={"username"}
        />
        <div className="mb-3">
          <label htmlFor="positionID" className="form-label">
            Position
          </label>
          <input
            type="text"
            className="form-control"
            id="positionID"
            value={userForm.position}
            onChange={(e) => changeData(e)}
            name="position"
          />
        </div>
        <button
          type="submit"
          disabled={errors.positionErr || errors.usernameErr}
          className="btn btn-primary"
        >
          Submit
        </button>
      </form>
    </div>
  );
}

// Create form [Bootstrap / Native ... ]
// Create State to control form
// Add [ value , onChange function , name ] attribute on fields [inputs , select ...]
// Define the change function
// In change function -> trigger input changes based on [e.target.name , e.target.value]
// Define Errors State to handle validation
// Set the rules for validation and set Errors state
// Define the errors text in JSX
