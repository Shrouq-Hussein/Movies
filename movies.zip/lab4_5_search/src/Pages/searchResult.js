import axios from 'axios'
import React from 'react'
import { useEffect, useState } from 'react'
import { useSelector, useDispatch } from "react-redux"
import { setLoaderAction } from "./../Store/Actions/loaderAction"
import Loader from "./../Components/Loader/loader"
import MovieCard from './../Components/movCard'
import { Link } from 'react-router-dom'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar ,faStarAndCrescent} from "@fortawesome/free-solid-svg-icons";
import { ADD_FavMovies ,Remove_FavMovies} from "./../Store/Actions/FavMovies";
import { Counter} from "./../Store/Actions/Counter";
import { useParams } from 'react-router-dom/cjs/react-router-dom.min'

export default function SearchResults() {
    //params
    const params = useParams();   //for dynamic params  like /:id

    const [results, setResults] = useState([])
    //redux
    const isloading = useSelector((state) => state.loader.isloading);
    const favourits = useSelector((state) => state.FavMovies.favMovies);
    const counter = useSelector((state) => state.counter.counter);

    const dispatch = useDispatch();
    let isFav = (id) => {
        return favourits.find(element => element === id)
    };

    const addRemoveMovieFav = (id) => {
        isFav(id)  ?  dispatch(Counter(counter-1)): dispatch(Counter(counter+1))
        isFav(id)
        ? dispatch(Remove_FavMovies(id))
        : dispatch(ADD_FavMovies(id))
    }

    useEffect(() => {
        axios.get(`https://api.themoviedb.org/3/search/movie?api_key=7a1c19ea3c361a4d3cc53eb70ef8298c&query=${params.title}`)
            .then((res) => {
                setResults(res.data.results)
                dispatch(setLoaderAction(false))
            })
            .catch((err) => console.log(err));
    }, []);
    return (
        <div>
            <h1 style={{ color: "#ecf0f1" }}>Moviees</h1>
            {
                isloading
                    ? (<Loader />)
                    : (<div className='row p-5' >
                        {results.map((movie, index) => {
                            return (
                                <div className="card col-lg-3 col-md-5 col-sm-6 offset-1 p-3 mb-5 " style={{ backgroundColor: "#ecf0f1" }} key={index}  >
                                    <Link key={"movie.id"} to={`/Details/${movie.id}`} >
                                        <img src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`} className="card-img-top" alt="..." />
                                    </Link>

                                    <div className="card-body">
                                        <div className='row'>
                                            <h5 className="card-title text-start col-6">{movie.title}</h5>
                                            <span className="text-end  col-6">
                                                <FontAwesomeIcon icon={
                                                    faStar
                                                    } 
                                                className="me-2 my-2" style={{ color: "orange" }} onClick={() => addRemoveMovieFav(movie.id)} />
                                            </span>
                                        </div>
                                        <span >Vote Average:</span>
                                        <span style={{ color: "red" }}> {movie.vote_average}</span>
                                        <span className='ms-3'>Vote Count:</span>
                                        <span style={{ color: "red" }}> {movie.vote_count}</span>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                    )
            }
        </div>
    )
}


