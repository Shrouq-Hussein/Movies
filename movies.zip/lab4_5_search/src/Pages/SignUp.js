import CustomInput from '../Components/Input'
import { useState } from "react";
import React from "react";
import {useHistory} from "react-router-dom"
export default function SignUp(props) {

    const history=useHistory();  //hook for props.history

    console.log(props)
    // useState is a hook function to intialize values in functional components
    const [SignupForm, setlogInForm] = useState(
        // initialState intial values
        {
            name: "",
            email: "",
            userName: "",
            password: "",
            confirmPassword: "",
        }
    )
    const [errors, setErrors] = useState(
        // initialState intial values
        {
            emailErr: "",
            passwordErr: "",
            nameErr:"",
            userNameErr:"",
            confirmPassErr:"",
        }
    )
   
    const changeData = (e) => {
        if (e.target.name === "userEmail") {
            console.log(e.target.value)
            setlogInForm({
                ...SignupForm,
                email: e.target.value,
            })
            setErrors({
                ...errors,
                emailErr: e.target.value.length === 0
                    ? "the email is required"
                    : /^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]{2,3}$/.test(e.target.value)
                        ? null
                        : "invaled email format"
                ,
            })

        }
        else if (e.target.name === "userPassword") {
            console.log(e.target.value);
            setlogInForm(
                {
                    ...SignupForm,
                    password: e.target.value,
                }
            )
            setErrors({
                ...errors,
                passwordErr: e.target.value.length === 0
                    ? "the password is required"
                    : /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(e.target.value)
                        ? null
                        :"week password, password length not less than 8 characters , contains at least one lowercase , one uppercase , at least one digit and special character"
                        ,
            })

        }
        else if (e.target.name === "Name") {
            console.log(e.target.value);
            setlogInForm(
                {
                    ...SignupForm,
                    name: e.target.value,
                }
            )
            setErrors({
                ...errors,
                nameErr:
                 e.target.value.length === 0
                    ? "name is required"
                    : null
                ,
            })

        }
        else if (e.target.name === "userName") {
            console.log(e.target.value);
            setlogInForm(
                {
                    ...SignupForm,
                    userName: e.target.value,
                }
            )
            setErrors({
                ...errors,
                userNameErr:
                 e.target.value.length === 0
                    ? "Username is required"
                    :!/^\S*$/.test( e.target.value)
                    ?"user name must be without spacing"
                    :null
                ,
            })

        }
        else if (e.target.name === "confirmPassword") {
            console.log( SignupForm.password);
            setlogInForm(
                {
                    ...SignupForm,
                    confirmPassword: e.target.value,
                }
            )
          
            setErrors({
                ...errors,
                confirmPassErr:
                 e.target.value.length === 0
                    ? "required"
                    : e.target.value !== SignupForm.password   //for confirmation password
                    ?"doesn't match password field "
                    :null
                ,
            })

        }
    }
   

    // Password toggle handler
    const [passwordShown, setPasswordShown] = useState(false);
    const togglePassword = () => {
        // When the handler is invoked
        // inverse the boolean state of passwordShown
        console.log(passwordShown);
        setPasswordShown(!passwordShown);
    };

    //submit and go to login page
    const submitUserDataForm = (e) => {
        e.preventDefault();
        if (!errors.emailErr && !errors.passwordErr) {
            // SEND API REQUEST
           history.push("/login");
        }
    }

    return (
        <div className="row">
            <form className=" col-6 p-5 text-start pb-5" method='get'>
                <h1 className='pb-3 '>SinUp Page</h1>
                <CustomInput
                    id={"nameid"}
                    label={"Name"}
                    errors={errors.nameErr}
                    value={SignupForm.name}
                    handleChange={(e) => changeData(e)}
                    name={"Name"}
                    type="text"
                />
                <CustomInput
                    id={"emailId"}
                    label={"UserEmail"}
                    errors={errors.emailErr}
                    value={SignupForm.email}
                    handleChange={(e) => changeData(e)}
                    name={"userEmail"}
                    type="text"
                />
                 <CustomInput
                    id={"usernameid"}
                    label={"userName"}
                    errors={errors.userNameErr}
                    value={SignupForm.userName}
                    handleChange={(e) => changeData(e)}
                    name={"userName"}
                    type="text"
                />
                <CustomInput
                    id={"passwordId"}
                    label={"UserPassword"}
                    errors={errors.passwordErr}
                    value={SignupForm.password}
                    handleChange={(e) => changeData(e)}
                    name={"userPassword"}
                    type={passwordShown ? "text" : "password"}
                />
                  <CustomInput
                    id={"confirmPassId"}
                    label={"Confirmation Password"}
                    errors={errors.confirmPassErr}
                    value={SignupForm.confirmPassword}
                    handleChange={(e) => changeData(e)}
                    name={"confirmPassword"}
                    type={passwordShown ? "text" : "password"}
                />
            


            
                <div className="btn btn-outline-light" onClick={togglePassword}>Show Password</div>
                <br></br>
                <br></br>
                <button  className="btn btn-light" onClick={submitUserDataForm}>Register</button>

            </form>

        </div>

    );
}