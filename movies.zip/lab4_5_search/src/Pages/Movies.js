import axios from 'axios'
import React from 'react'
import { useEffect, useState } from 'react'
import { useSelector, useDispatch } from "react-redux"
import { setLoaderAction } from "./../Store/Actions/loaderAction"
import Loader from "./../Components/Loader/loader"
import MovieCard from './../Components/movCard'
import { Link } from 'react-router-dom'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar ,faStarAndCrescent} from "@fortawesome/free-solid-svg-icons";
import { ADD_FavMovies ,Remove_FavMovies} from "./../Store/Actions/FavMovies";
import { Counter} from "./../Store/Actions/Counter";
import {getMovies} from "./../Store/Actions/MoviesList";
export default function Movies() {
    //routing |for card component
    // const [movies, setMovies] = useState([])
    const movies = useSelector( (state) => state.MOVIES_LIST.list)
    //redux
    const isloading = useSelector((state) => state.loader.isloading);
    const favourits = useSelector((state) => state.FavMovies.favMovies);
    const counter = useSelector((state) => state.counter.counter);

    const dispatch = useDispatch();

    console.log("favourits ",favourits)

    let isFav = (id) => {
        return favourits.find(element => element === id)
    };

    const addRemoveMovieFav = (id) => {
        isFav(id)  ?  dispatch(Counter(counter-1)): dispatch(Counter(counter+1))
        isFav(id)
        ? dispatch(Remove_FavMovies(id))
        : dispatch(ADD_FavMovies(id))
        // console.log(id, "movie : addMovieToFav")
        console.log("counter  ",counter)
    }

    useEffect(() => {
        // axios.get('https://api.themoviedb.org/3/movie/popular?api_key=33ee69aaee111a0f8e24cb998b626bfe')
        //     .then((res) => {
        //         setMovies(res.data.results)
        //         dispatch(setLoaderAction(false))
        //     })
        //     .catch((err) => console.log(err));
        dispatch(getMovies())
    }, []);
    // console.log(movies)
    return (
        <div>
            <h1 style={{ color: "#ecf0f1" }}>Moviees</h1>
            {
                isloading
                    ? (<Loader />)
                    : (<div className='row p-5' >
                        {movies.map((movie, index) => {
                            return (
                                <div className="card col-lg-3 col-md-5 col-sm-6 offset-1 p-3 mb-5 " style={{ backgroundColor: "#ecf0f1" }} key={index}  >
                                    <Link key={"movie.id"} to={`/Details/${movie.id}`} >
                                        <img src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`} className="card-img-top" alt="..." />
                                    </Link>

                                    <div className="card-body">
                                        <div className='row'>
                                            <h5 className="card-title text-start col-6">{movie.title}</h5>
                                            <span className="text-end  col-6">
                                                <FontAwesomeIcon icon={
                                                    faStar
                                                    } 
                                                className="me-2 my-2" style={{ color: "orange" }} onClick={() => addRemoveMovieFav(movie.id)} />
                                            </span>
                                        </div>
                                        <span >Vote Average:</span>
                                        <span style={{ color: "red" }}> {movie.vote_average}</span>
                                        <span className='ms-3'>Vote Count:</span>
                                        <span style={{ color: "red" }}> {movie.vote_count}</span>
                                    </div>
                                </div>
                                // < MovieCard
                                // id={index}
                                // title={movie.title}
                                // poster={movie.poster_path}
                                // vote_average={movie.vote_average}
                                // vote_count={movie.vote_count} 
                                // movi={movie}
                                // />

                            )
                        })}
                    </div>
                    )
            }
        </div>
    )
}
//promise (resolve or reject)
//resolve -> .then
//reject -> catchh()  reject l promise

