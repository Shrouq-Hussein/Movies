import React from "react";
import { connect } from "react-redux";
import UserData from "../components/UserData/UserData";
import ChangeLanguage from "./../components/ChangeLanguage/ChangeLanguage";
import { changeLanguage } from "../store/actions/language";

// const  name = 'marina'; xxxxxxxxxxxxxxx

class ExampleClassComponent extends React.Component {
  constructor() {
    console.log("CONSTRUCTOR");
    super();
    this.state = {
      name: "Marina",
      position: "Frontend Developer",
    };
  }

  componentDidMount() {
    // CALLING API [HTTP REQUESTS - AJAX]
    console.log("DID MOUNT");
  }

  componentDidUpdate() {
    // BASED ON CHANGES DO SOMETHING
    console.log("DID UPDATED");
  }

  componentWillUnmount() {
    // COMPONENT WILL BE DESTROYED
    console.log("DESTROY");
  }

  changeUsername = (name) => {
    console.log("CLICK USER NAME");
    // this.state.name = 'Ahmed' xxxxxx WRONG xxxxxxxxx

    this.setState({
      name: name,
    });
  };

  render() {
    console.log("RENDER");
    console.log(this.props);
    return (
      <>
        <ChangeLanguage /> 
        <hr />
        <h3 className="text-success">
          Class Component Language : {this.props.lang}
        </h3>
        <h1>Hello from Class Component</h1>
        <UserData
          userName={this.state.name}
          userPosition={this.state.position}
        />
        <button className="btn btn-danger" onClick={() => this.props.changeLanguage(this.props.lang === "ar" ? "en" : "ar")}>
          Change Lang
        </button>
        <button className="btn btn-primary mx-4" onClick={() => this.changeUsername("Youssef")}>
          Change Username
        </button>
      </>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    lang: state.language.lang,
  };
};
//mapStateToProps dy function na ly m3arfaha 
// btb2a shaela state w btreturn object  badal l useSelector() 
// dlwa2ty props bta3et class component

// {
//   changeLanguage,
// }
// fire change language action in class component

export default connect(mapStateToProps, {
  changeLanguage,
})(ExampleClassComponent);
