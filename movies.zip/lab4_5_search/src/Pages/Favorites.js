import axios from 'axios'
import React from 'react'
import { useEffect, useState } from 'react'
import { useSelector, useDispatch } from "react-redux"
import { setLoaderAction } from "./../Store/Actions/loaderAction"
import Loader from "./../Components/Loader/loader"
import MovieCard from './../Components/movCard'
import { Link } from 'react-router-dom'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar} from "@fortawesome/free-solid-svg-icons";
import { Remove_FavMovies } from "./../Store/Actions/FavMovies";
import { Counter} from "./../Store/Actions/Counter";

export default function Favorites() {
    //routing |for card component
    const [movies, setMovies] = useState([])
    //redux
    const isloading = useSelector((state) => state.loader.isloading);
    const counter = useSelector((state) => state.counter.counter);

    const dispatch = useDispatch();
    const favourits = useSelector((state) => state.FavMovies.favMovies);
    console.log(favourits)
    const remove = (id) => {
        dispatch(Counter(counter-1))
        setMovies(movies.filter((e) => e.id != id)) 
        dispatch(Remove_FavMovies(id))
    }
   
  useEffect(() => {
    let urls = favourits.map(
      (id) =>
        `https://api.themoviedb.org/3/movie/${id}?api_key=33ee69aaee111a0f8e24cb998b626bfe`
    );
    axios
      .all(urls.map((url) => axios.get(url).then((res) => res.data)))
      .then((resArray) => setMovies([...movies, ...resArray]));
  }, []);

    console.log(movies)

    // useEffect(() => {}, [favourits]);

    return (
        <div>
            <h1 style={{ color: "#ecf0f1" }}>Moviees</h1>
            {
                isloading
                    ? (<Loader />)
                    : (<div className='row p-5' >
                        {movies.map((movie, index) => {
                            return (
                                <div className="card col-lg-3 col-md-5 col-sm-6 offset-1 p-3 mb-5 " style={{ backgroundColor: "#ecf0f1" }} key={index}  >
                                    <Link key={"movie.id"} to={`/Details/${movie.id}`} >
                                        <img src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`} className="card-img-top" alt="..." />
                                    </Link>

                                    <div className="card-body">
                                        <div className='row'>
                                            <h5 className="card-title text-start col-6">{movie.title}</h5>
                                            <span className="text-end  col-6">
                                                <FontAwesomeIcon icon={
                                                    faStar
                                                    //  isFav(movie)
                                                    // ? faStar
                                                    // :faregStar
                                                    } 
                                                className="me-2 my-2" style={{ color: "orange" }} onClick={() => remove(movie.id)} />
                                            </span>
                                        </div>
                                        <span >Vote Average:</span>
                                        <span style={{ color: "red" }}> {movie.vote_average}</span>
                                        <span className='ms-3'>Vote Count:</span>
                                        <span style={{ color: "red" }}> {movie.vote_count}</span>
                                    </div>
                                </div>
                                // < MovieCard
                                // id={index}
                                // title={movie.title}
                                // poster={movie.poster_path}
                                // vote_average={movie.vote_average}
                                // vote_count={movie.vote_count} 
                                // movi={movie}
                                // />

                            )
                        })}
                    </div>
                    )
            }
        </div>
    )
}
//promise (resolve or reject)
//resolve -> .then
//reject -> catchh()  reject l promise

