import React from 'react'
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom/cjs/react-router-dom.min'
import axios from 'axios'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLinkedin, faStar } from "@fortawesome/free-solid-svg-icons";
import ChangeLanguage from '../Components/ChangeLanguage/ChangeLanguage';
import { useSelector, useDispatch } from "react-redux"
import { ADD_FavMovies } from "./../Store/Actions/FavMovies";

export default function MovieDetails() {
    const favourits = useSelector((state) => state.FavMovies.favMovies);
    console.log(favourits, "favlist")
        const dispatch = useDispatch();

    const addMovieToFav = () => {
        dispatch(ADD_FavMovies(details))
        console.log(details,"details1")
    }

    ///////////////////////////////////
    const params = useParams();   //for dynamic params  like /:id
    const [details, setDetails] = useState({})

    console.log(params);
    useEffect(() => {
        //axios.get(`https://fakestoreapi.com/users/${params.id}`)
        axios.get(`https://api.themoviedb.org/3/movie/${params.id}?api_key=33ee69aaee111a0f8e24cb998b626bfe`)
            .then((res) => setDetails(res.data))
            .catch((err) => { console.log(err) });
    }, [])
console.log("details",details)
    return (
        <div className='row p-5'>
            <h1>Details</h1>
            <div className="card col-6 offset-3" style={{ backgroundColor: "#ecf0f1" }} key={details.id}>
                <img src={`https://image.tmdb.org/t/p/w500/${details.poster_path}`} className="card-img-top img-fluid p-5" alt="..." />
                <div className="card-body">
                    <div className='row'>
                        <h4 className="card-title text-start col-6" style={{ color: "red" }}>{details.title}</h4>
                        <span className="text-end  col-6">
                            <FontAwesomeIcon icon={faStar} className="me-2 my-2" style={{ color: "orange" }} onClick={() => addMovieToFav()} />
                        </span>
                    </div>
                    <h5 className='card-title text-start'>Overview: </h5>
                    <p className="card-text text-start">{details.overview}</p>
                    <span >Vote Average:</span>
                    <span style={{ color: "red" }}> {details.vote_average}</span>
                    <span className='ms-5'>Vote Count:</span>
                    <span style={{ color: "red" }}> {details.vote_count}</span>
                </div>
            </div>
            {/* <ChangeLanguage/> */}

        </div>
    )
}
/*adult: false
backdrop_path: "/c6H7Z4u73ir3cIoCteuhJh7UCAR.jpg"
genre_ids: (4) [28, 12, 14, 878]
id: 524434
original_language: "en"
original_title: "Eternals"
overview: "The Eternals are a team of ancient aliens who have been living on Earth in secret for thousands of years. When an unexpected tragedy forces them out of the shadows, they are forced to reunite against mankind’s most ancient enemy, the Deviants."
popularity: 10421.733
poster_path: "/b6qUu00iIIkXX13szFy7d0CyNcg.jpg"
release_date: "2021-11-03"
title: "Eternals"
video: false
vote_average: 7.2
vote_count: 2982 */