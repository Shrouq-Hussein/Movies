import CustomInput from '../Components/Input'
import { useState } from "react";
import {useHistory} from "react-router-dom"

export default function Login() {
    const history=useHistory();  //hook for props.history

    //submit and go to login page
    const submitUserDataForm = (e) => {
        e.preventDefault();
        if (!errors.emailErr && !errors.passwordErr) {
            // SEND API REQUEST
           history.push("/Movies");
        }
    }
    // useState is a hook function to intialize values in functional components
    const [logInForm, setlogInForm] = useState(
        // initialState intial values
        {
            email: "",
            password: "",
        }
    )
    const [errors, setErrors] = useState(
        // initialState intial values
        {
            emailErr: "",
            passwordErr: "",
        }
    )
    const [passwordShown, setPasswordShown] = useState(false);
    const changeData = (e)=>{
        if(e.target.name ==="userEmail")
        {
            console.log(e.target.value)
            setlogInForm({
                ...logInForm,
                email: e.target.value,
              })
              setErrors({
                ...errors,
                emailErr: e.target.value.length === 0
                ?"the email is required"
                :/^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]{2,3}$/.test(e.target.value)
                ? null
                :"invaled email format"
                ,
              })

        }
        else if(e.target.name === "userPassword"){
            console.log(e.target.value);
            setlogInForm(
                {
                    ...logInForm,
                    password:e.target.value,
                }
            )
            setErrors({
                ...errors,
                passwordErr: e.target.value.length === 0
                ?"the password is required"
                :/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(e.target.value)
                ? null
                :"wrong password"
                ,
              })

        }
    }

    // Password toggle handler
    const togglePassword = () => {
      // When the handler is invoked
      // inverse the boolean state of passwordShown
      console.log(passwordShown);
      setPasswordShown(!passwordShown);
    };

    return (
        <div className="row" style={{height:"100vh"}}>
            <form className=" col-6 p-5 text-start">
               <h1 className='pb-3 '>logIn Page</h1>
                <CustomInput
                id={"emailId"}
                label={"UserEmail"}
                errors={errors.emailErr}
                value={logInForm.email}
                handleChange={(e) => changeData(e)}
                name={"userEmail"}
                type="text"
                />
                <CustomInput
                id={"passwordId"}
                label={"UserPassword"}
                errors={errors.passwordErr}
                value={logInForm.password}
                handleChange={(e) => changeData(e)}
                name={"userPassword"}
                type={passwordShown ? "text" : "password"}
                />
                  {/* <div className="mb-3 ">
                    <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                    <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                    <div id="emailHelp" className="form-text"></div>
                </div> */}
                 {/* <div className="mb-3">
                    <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                    <input type="password" className="form-control" id="exampleInputPassword1" />
                </div>
                <div id="passwordHelp" className="form-text"></div> */}
                 <div className="btn btn-outline-light" onClick={togglePassword}>Show Password</div>
                 <br></br>
                 <br></br>
                 <button type="submit" className="btn btn-light" onClick={submitUserDataForm}>Login</button>
               
            </form>

        </div>

    );
}