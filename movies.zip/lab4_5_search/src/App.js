import logo from './logo.svg';
import './App.css';
import AddUser from "./Pages/AddUser";
import Login from "./Pages/loginForm";
import SignUp from "./Pages/SignUp";
import Movies from "./Pages/Movies";
import Favorites from "./Pages/Favorites";
import Details from "./Pages/MovieDetails";
import SearchResults from "./Pages/searchResult";
import NavBar from "./Components/NavBar";
import NotFound from "./Components/NotFound";
import { BrowserRouter, Route, Switch} from "react-router-dom"
import { useSelector } from 'react-redux';
import {LanguageContext} from './Context/languageContext'
import { useState } from 'react';
//  BrowserRouter  da lrapper lkber b2et l tags gwah
// ,3ando properties bydeha llchield components ly tahteh

function App() {
  const lanuuage = useSelector((state) => state.lanuuage);
  const [contextLanguage,setContextLanguage] = useState("EN") //3shan tb2a dynamic value w bbasy l value wl seter bta3tha ll context provider 
  return (
    // <div className={`App ${lanuuage === 'AR'?"text-end":"text-start"}` }dir={lanuuage === 'AR'? "rtl":"ltr"}>
    <div className="App">
      <LanguageContext.Provider value={{contextLanguage,setContextLanguage}}>
      <BrowserRouter>
      <NavBar/>
      <div className='my_container'>
        <Switch>
          {/* default page */}
          <Route path={"/"} exact component={SignUp} />
          <Route path={"/SignUp"} exact component={SignUp} />
          <Route path={"/Login"} exact component={Login} />
          <Route path={"/Movies"} exact component={Movies} />
          <Route path={"/Favorites"} exact component={Favorites} />
          <Route path={"/Details/:id"} exact component={Details} />
          <Route path={"/SearchResults/:title"} exact component={SearchResults} />
          <Route path={"*"}  component={NotFound} />
        </Switch>
        </div>
      </BrowserRouter>
      </LanguageContext.Provider>
    </div>
  
  );
}

export default App;
