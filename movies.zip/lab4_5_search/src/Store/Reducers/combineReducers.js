import { combineReducers } from "redux";
import changeLanguage from "./changeLanguage"
import loaderReducer from "./loaderReducer"
import Counter from "./Counter"
import favMovies from "./FavMovies"
import moviesList from "./MoviesList"
// combineReducers is built in function in redux
export default combineReducers(
    {
        language: changeLanguage,
        loader: loaderReducer,
        counter: Counter,
        FavMovies:favMovies,
        MOVIES_LIST: moviesList,
    }
);
