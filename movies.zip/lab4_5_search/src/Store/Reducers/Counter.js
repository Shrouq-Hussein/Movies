//component function
export default function Counter(state = INITIAL_VALUE,action) {
    //according to action type change state specific value or default intial state or previous state
        switch(action.type){
            case "CHANGE_COUNTER":
            return (
                {
                    ...state,
                    counter:action.payload,
                }
            )
            default:
                return state;
        } 
}

const INITIAL_VALUE={
    counter:0,

}