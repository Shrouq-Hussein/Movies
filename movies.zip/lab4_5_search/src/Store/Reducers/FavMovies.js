//component function
export default function FavMovies(state=INITIAL_VALUE,action) {
    //according to action type change state specific value or default intial state or previous state
        switch(action.type){
            case "ADD_MOVIE":
                // console.log("action.payload: ",action.payload);
                // state = state.concat(action.payload);
                console.log("favMovies",state.favMovies);
            return {
                ...state,
                 favMovies:[...state.favMovies,action.payload]
            }
            case "REMOVE_MOVIE":
                return{
                    favMovies: state.favMovies.filter((e) => e != action.payload)   //byhut fav movies ma3ada ly 3ayzen nmsaho ly hwa action.payload
                }
            default:
                return state;
        } 
}

const INITIAL_VALUE={
    favMovies:[],

}