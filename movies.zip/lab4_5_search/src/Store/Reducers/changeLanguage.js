//component function
export default function LanguageReducer(state = INITIAL_VALUE,action) {
    //according to action type change state specific value or default intial state or previous state
        switch(action.type){
            case"CHANGE_LANGUAGE":
            return (
                {
                    ...state,
                    lang:action.payload,
                }
            )
            default:
                return state;
        } 
}

const INITIAL_VALUE={
    lang:"en",

}