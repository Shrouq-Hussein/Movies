export const ADD_FavMovies=
(payload) =>{
    return{
        type:"ADD_MOVIE",
        payload,
    }

}

export const Remove_FavMovies=
(payload) =>{
    return{
        type:"REMOVE_MOVIE",
        payload,
    }

}