// export const setMovies = (payload) =>{
//     return{
//         type:"GET_MOVIES",
//         payload,
//     }

// }
import axios from 'axios'
import { setLoaderAction } from "./loaderAction"

export const getMovies = () => (dispatch) => {

    return axios.get('https://api.themoviedb.org/3/movie/popular?api_key=33ee69aaee111a0f8e24cb998b626bfe')
    .then((res) => 
    {
        //second dispatch de mesh bt fire 8er lma l data trga3 
        // ha set l data fl store
        dispatch({
            type: "GET_MOVIES",
            payload: res.data.results,

        })
        dispatch(setLoaderAction(false))
    }        
    )
    .catch((err) => console.log(err));
}