export const setLoaderAction=
(payload) =>{
    return{
        type:"SET_LOADER",
        payload,
    }

}