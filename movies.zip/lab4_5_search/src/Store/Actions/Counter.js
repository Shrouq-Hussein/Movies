export const Counter=
(payload) =>{
    return{
        type:"CHANGE_COUNTER",
        payload,
    }

}