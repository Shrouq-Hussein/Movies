//function 3adya mesh component return object type & payload
export const changeLanguageAction=
(payload) => {
    return{
        type:"CHANGE_LANGUAGE",
        payload,
    }
} 
   
